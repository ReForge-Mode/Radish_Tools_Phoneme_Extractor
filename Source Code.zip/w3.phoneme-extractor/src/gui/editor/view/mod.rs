//
// gui::editor::view
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub mod misc;
pub mod table;
pub mod timeline;
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------

// actions
use super::{Action as EditorAction, TimelineAction};

// state
use super::{EditableData, PhonemeDragMode, Settings};

// misc
use super::{PhonemeSegment, PhonemeTrack};
use super::{MAX_ZOOM, MIN_ZOOM};

// util
use super::{Fonts, UiArea};
// ----------------------------------------------------------------------------
