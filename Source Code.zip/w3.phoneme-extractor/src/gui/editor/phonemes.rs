//
// editor::phonemes
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
/// phoneme gaps closing on de/activation of phoneme segment
pub(super) fn update_timings_on_activation(
    max_position: u32,
    phonemes: &mut Vec<PhonemeSegment>,
    slot: usize,
    activated: bool,
) {
    // find active neighboring phoneme segments that do not cross word boundary
    let (pred, succ) = phonemes.split_at_mut(slot);
    let (segment, succ) = succ.split_at_mut(1);

    let segment = &mut segment[0];
    segment.active = activated;

    let mut predecessor = pred
        .iter()
        .enumerate()
        .rev()
        .find(|&(_, segment)| segment.active || segment.word_start)
        .map(|(i, segment)| (i, segment.active));

    let mut successor = None;
    for (i, current) in succ.iter().enumerate() {
        if current.word_start {
            break;
        }
        successor = Some((i, current.active));

        if current.active {
            break;
        }
    }

    if segment.word_start {
        predecessor = None;
    }

    if activated {
        let duration = segment.end.saturating_sub(segment.start);
        let segment_mid = segment.start as f32 + duration as f32 * 0.5;
        // default duration := 50
        let duration = u32::max(50, duration) as f32;

        // clip at 0 and audio clip length
        let mut start = clamp_ms(segment_mid - duration * 0.5, 5.0, 0, segment.end);
        let mut end = clamp_ms(segment_mid + duration * 0.5, 5.0, start, max_position);

        if let Some((slot, _)) = predecessor {
            pred.iter_mut().skip(slot).for_each(|p| {
                if p.active {
                    p.end = clamp_ms(
                        p.start as f32 + (p.end as f32 - p.start as f32) * 0.75,
                        5.0,
                        p.start,
                        p.end,
                    );
                } else {
                    p.start = start;
                    p.end = start;
                }
                start = p.end;
            });
        }
        if let Some((slot, _)) = successor {
            succ.iter_mut()
                .enumerate()
                .rev()
                .skip_while(|&(i, _)| i > slot)
                .for_each(|(_, s)| {
                    if s.active {
                        s.start = clamp_ms(
                            s.start as f32 + (s.end as f32 - s.start as f32) / 3.0,
                            // hardcoded 5 ms granularity
                            5.0,
                            s.start,
                            s.end,
                        );
                    } else {
                        s.start = end;
                        s.end = end;
                    }
                    end = s.start;
                });
        }
        segment.start = start;
        segment.end = end;
    } else {
        let active_predecessor = predecessor.map_or(false, |(_, active)| active);
        let active_successor = successor.map_or(false, |(_, active)| active);

        let segment_mid = segment.start + segment.end.saturating_sub(segment.start) / 2;

        #[allow(clippy::match_bool)]
        let new_pos = match active_predecessor {
            true if active_successor => segment_mid,
            true if !active_successor => segment.end,
            false if active_successor => segment.start,
            false if !active_successor => segment_mid,
            _ => unreachable!(),
        };

        if let Some((slot, _)) = predecessor {
            pred.iter_mut().skip(slot).for_each(|p| {
                if !p.active {
                    p.start = new_pos;
                }
                p.end = new_pos;
            });
        }

        segment.start = new_pos;
        segment.end = new_pos;

        if let Some((slot, _)) = successor {
            succ.iter_mut().take(slot + 1).for_each(|s| {
                if !s.active {
                    s.end = new_pos;
                }
                s.start = new_pos;
            });
        }
    }
}
// ----------------------------------------------------------------------------

use super::clamp_ms;
use super::PhonemeSegment;
