//
// gui::cmds - more complex actions with (possible) side effects
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub(super) fn handle_change_dir(
    new_dir: PathBuf,
    state: &mut State,
    worker_pool: &mut WorkerThreadPool,
) -> Result<(), String> {
    state.editor_data.reset();

    let stringsfile = match worker_pool.params.stringsfile {
        Some(ref file) => Ok(file.clone()),
        None => ::search_strings_file(&new_dir),
    }?;

    // -- reinit idselector
    state.lineid_selector.init_strings_provider(&stringsfile)?;

    // -- reinit workerthreads
    // TODO if a different language has to be used (e.g.
    // extracted from strings file or directory name)
    // the workers have to be reinitialized. since the espeak
    // wrapper/lib is not multithreaded the threads need to be
    // stopped before new worker threads can be started

    // changing directory means the new strings have to be reloaded in every
    // worker thread
    // -> simplest solution: send stop signal and block ui thread
    for &(_, ref stop_signal) in &worker_pool.threads {
        // ignore result
        stop_signal.send(()).ok();
    }
    for (worker, _) in worker_pool.threads.drain(..) {
        worker.join().ok();
    }

    // start new worker
    for _ in worker_pool.threads.len()..worker_pool.max_count {
        worker_pool.threads.push(worker::start(
            worker_pool.params.error_channel.clone(),
            worker_pool.params.tasks.clone(),
            worker_pool.params.language.clone(),
            stringsfile.clone(),
            worker_pool.params.datadir.clone(),
            worker_pool.params.loglevel,
        ));
        thread::sleep(::std::time::Duration::from_millis(100));
    }

    state
        .audioqueue
        .init_from_directory(&new_dir.to_string_lossy())
        .unwrap();

    state.fileio = filebrowser::FileChooserState::new(&new_dir);
    state.current_dir = new_dir;

    Ok(())
}
// ----------------------------------------------------------------------------
pub(super) fn save_phoneme_track(
    outputdir: &PathBuf,
    data: &mut editor::EditableData,
) -> Result<(), String> {
    use phonemes::{PhonemeSegment, PhonemeTrack};

    // increase version for saving
    let version = data.phonemetrack().version() + 1;
    let mut track: PhonemeTrack<PhonemeSegment> = data.phonemetrack().into();
    track.set_version(version);

    ::phonemes::store(outputdir, track).map(|_| data.set_as_saved(version))
}
// ----------------------------------------------------------------------------
pub(super) fn assign_lineid(
    data: IdAssignmentActionData,
    queue: &mut queue::AudioQueue,
) -> Result<(), String> {
    use std::fs;

    if queue.contains_task_by_lineid(data.lineid) {
        Err(format!(
            "Line id assignment failed: \n\naudioqueue already contains \
             an audiofile with the lineid {}",
            data.lineid
        ))
    } else {
        let task = queue.remove_task(data.id)?;

        let old_audiofile = PathBuf::from(task.audiofile());
        let extension = old_audiofile
            .extension()
            .ok_or_else(|| "failed to extract audiofile extension")?;

        let new_audiofile = format!(
            "{:0>10}[{:.4}]{}.{}",
            data.lineid,
            data.duration,
            ::escape_textline(&data.text)?,
            extension.to_string_lossy()
        );

        info!("renaming audiofile to: {}", new_audiofile);
        let new_audiofile = old_audiofile.with_file_name(new_audiofile);

        fs::rename(&old_audiofile, &new_audiofile)
            .map_err(|err| format!("failed to rename {}: {}", old_audiofile.display(), err))?;

        // potentially existing phoneme file for this lineid will be overriden
        // because the audiofile is added with a "waiting" processing state
        queue.add_audiofile(data.lineid, &new_audiofile.to_string_lossy())
    }
}
// ----------------------------------------------------------------------------
pub(super) fn force_renaming(queue: &mut queue::AudioQueue) -> Result<(), String> {
    queue.force_renaming()?;
    queue.refresh_captions();
    Ok(())
}
// ----------------------------------------------------------------------------
//
// ----------------------------------------------------------------------------
use std::path::PathBuf;
use std::thread;

use super::editor;
use super::filebrowser;
use super::queue;
use super::worker;

use super::{IdAssignmentActionData, State, WorkerThreadPool};
// ----------------------------------------------------------------------------
