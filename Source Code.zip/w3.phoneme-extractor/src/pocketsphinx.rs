//
// phoneme extractor
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
extern crate pocketsphinx;

pub struct PocketSphinx {
    decoder: pocketsphinx::PsDecoder,
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use std::path::PathBuf;

use logger::LevelFilter;

use phonemes::{PhonemeResult, PhonemeSegment};
// ----------------------------------------------------------------------------
#[cfg(target_os = "linux")]
fn get_null_logfile() -> &'static str {
    "/dev/null"
}
#[cfg(target_os = "windows")]
fn get_null_logfile() -> &'static str {
    "NUL"
}
const POCKETSPHINX_BEAM: &str = "1e-20";
const POCKETSPHINX_PBEAM: &str = "1e-20";
const POCKETSPHINX_LW: &str = "2.0";
// max number of silence/speech frames to keep before change of state. if silence
// interval is too long this WILL mixup the resulting timings!
// (set by -vad_postspeech && -vad_prespeech)
const POCKETSPHINX_FRAMES_TO_KEEP: i32 = 500;
// ----------------------------------------------------------------------------
impl PocketSphinx {
    // ------------------------------------------------------------------------
    pub fn new(modeldir: &str, language: &str, loglevel: LevelFilter) -> Result<Self, String> {
        let modeldir = format!("{}/pocketsphinx/{}", modeldir, language);
        let phoneme_model = format!("{}/{}-phone.lm.bin", modeldir, language);

        debug!("initializing pocketsphinx:");
        debug!("> model directory: [{}]", modeldir);
        debug!("> language model: [{}]", phoneme_model);

        let modeldir = Self::check_dir(&modeldir)?;
        let phoneme_model = Self::check_file(&phoneme_model)?;

        trace!(">> cli parameters:");
        trace!(">> -hmm {}", modeldir);
        trace!(">> -allphone {}", phoneme_model);
        trace!(">> -backtrace yes");
        trace!(">> -beam {}", POCKETSPHINX_BEAM);
        trace!(">> -pbeam {}", POCKETSPHINX_PBEAM);
        trace!(">> -lw {}", POCKETSPHINX_LW);
        trace!(">> -vad_postspeech {}", POCKETSPHINX_FRAMES_TO_KEEP);
        trace!(">> -vad_prespeech {}", POCKETSPHINX_FRAMES_TO_KEEP);

        let max_frames = format!("{}", POCKETSPHINX_FRAMES_TO_KEEP);

        let mut options = vec![
            "-hmm",
            modeldir,
            "-allphone",
            phoneme_model,
            "-backtrace",
            "yes",
            "-beam",
            POCKETSPHINX_BEAM,
            "-pbeam",
            POCKETSPHINX_PBEAM,
            "-lw",
            POCKETSPHINX_LW,
            "-vad_postspeech",
            &max_frames,
            "-vad_prespeech",
            &max_frames,
        ];
        // pocketsphinx logging only in trace level
        if loglevel != LevelFilter::Trace {
            trace!(">> -logfn {}", get_null_logfile());
            options.push("-logfn");
            options.push(get_null_logfile());
        } else {
            //FIXME passing dynamic number of parameters to variadic foreign functions
            // ATM hardcoded to 9 parameter tuples
            // -> repeat one parameter twice
            options.push("-backtrace");
            options.push("yes");
        }

        let ps_config = match pocketsphinx::CmdLn::init(false, &options) {
            Ok(conf) => conf,
            Err(msg) => return Err(format!("{}", msg)),
        };
        let ps_decoder = pocketsphinx::PsDecoder::init(ps_config);

        Ok(PocketSphinx {
            decoder: ps_decoder,
        })
    }
    // ------------------------------------------------------------------------
    fn check_dir(dir: &str) -> Result<&str, String> {
        let dirpath = PathBuf::from(&dir);
        if !dirpath.exists() || !dirpath.is_dir() {
            Err(format!("directory [{}] does not exist", dirpath.display()))
        } else {
            Ok(dir)
        }
    }
    // ------------------------------------------------------------------------
    fn check_file(file: &str) -> Result<&str, String> {
        let filepath = PathBuf::from(&file);
        if !filepath.exists() || !filepath.is_file() {
            Err(format!("file [{}] does not exist", filepath.display()))
        } else {
            Ok(file)
        }
    }
    // ------------------------------------------------------------------------
    pub fn extract_phonemes(&self, raw_audio_data: &[i16]) -> Result<PhonemeResult, String> {
        trace!("> pocketsphinx: extracting phonemes...");

        if let Err(msg) = self.decoder.start_utt(Some("id")) {
            return Err(format!("{}", msg));
        }

        // returns number of frames of data that was searched, or <0 for error
        let frames = match self.decoder.process_raw(&raw_audio_data, false, true) {
            Ok(frames) => frames,
            Err(msg) => return Err(format!("{}", msg)),
        };
        trace!(">> {} frames of data searched", frames);

        if let Err(msg) = self.decoder.end_utt() {
            return Err(format!("{}", msg));
        }

        let hypothesis = match self.decoder.get_hyp() {
            Some((hyp, _utt_id, _score)) => Some(hyp),
            None => None,
        };

        let mut result = PhonemeResult {
            hypothesis,
            phonemes: Vec::new(),
        };

        // WORKAROUND for duped segments
        let mut prev_start = -1;
        for segment in self.decoder.seg_iter() {
            let phoneme = segment.word();
            let (start, end) = segment.frames();
            // check if duration of phoneme (especially SIL) don't overflow max
            // frames kept in buffer as this makes following timings invalid
            if end - start >= POCKETSPHINX_FRAMES_TO_KEEP {
                return Err(format!(
                    "phoneme segment [{}: {} - {}] exceeded max \
                     length (> {}). all following timings would be incorrect.",
                    &phoneme, start, end, POCKETSPHINX_FRAMES_TO_KEEP
                ));
            }
            if prev_start < start {
                prev_start = start;
                result.phonemes.push(PhonemeSegment {
                    phoneme: phoneme.to_owned(),
                    // no information about word boundaries
                    word_start: false,
                    // save timings as ms
                    start: start as u32 * 10,
                    end: end as u32 * 10,
                    weight: 1.0,
                    score: 0.0,
                    matching_info: None,
                    traceback: None,
                    active: true,
                });
            }
        }
        // postprocessing:
        // remove timing gaps between neighboring phonemes (except SIL) by
        // extending start & end
        let len = result.phonemes.len();
        if len > 2 {

            let mut is_prev_sil = true;

            for i in 0..len {

                is_prev_sil = if result.phonemes[i].phoneme != "SIL" {
                    if !is_prev_sil {
                        result.phonemes[i].start -= 5;
                    }
                    false
                } else {
                    true
                };

                if i + 1 < len && result.phonemes[i + 1].phoneme != "SIL" {
                    result.phonemes[i].end += 5;
                }
            }
        }

        Ok(result)
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
