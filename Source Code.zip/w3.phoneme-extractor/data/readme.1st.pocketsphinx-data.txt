Language and phoneme model for pocketsphinx has to be downloaded from the pocketsphinx
src repository:

- create a subfolder "en" in the data/pocketsphinx folder

- download the en-us language model (content of the folder) from

	https://github.com/cmusphinx/pocketsphinx/tree/master/model/en-us/en-us/

  and put it directly into the data/pocketsphinx/en folder

- download the en-us phoneme model from

	https://github.com/cmusphinx/pocketsphinx/blob/master/model/en-us/en-us-phone.lm.bin

  and put it directly into the data/pocketsphinx/en folder

- rename the en-us-phone.lm.bin file to en-phone.lm.bin
