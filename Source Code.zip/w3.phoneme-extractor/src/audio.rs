//
// audio loader
//
extern crate hound;
extern crate lewton;
extern crate sample;

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub struct AudioData {
    pub values: Vec<i16>,
    pub resampled: bool,
}
// ----------------------------------------------------------------------------
pub struct AudioLoader;
pub struct AudioResampler;
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
#[derive(Eq, PartialEq)]
struct FormatSpec {
    channels: u8,
    sample_rate: u32,
    bits: u16,
}
// ----------------------------------------------------------------------------
impl FormatSpec {
    // ------------------------------------------------------------------------
    fn new(channels: u8, sample_rate: u32, bits: u16) -> FormatSpec {
        FormatSpec {
            channels,
            sample_rate,
            bits,
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl AudioData {
    // ------------------------------------------------------------------------
    fn new(values: Vec<i16>, resampled: bool) -> AudioData {
        AudioData { values, resampled }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl AudioLoader {
    // ------------------------------------------------------------------------
    pub fn load(file: &str, target_samplerate: u32) -> Result<AudioData, String> {
        let (format, mut values): (_, Vec<i16>) = match file {
            s if s.ends_with(".wav") => {
                let decoder = WavDecoder::new(file)?;
                (decoder.format(), decoder.collect())
            }
            s if s.ends_with(".ogg") => {
                let decoder = OggDecoder::new(file)?;
                (decoder.format(), decoder.collect())
            }
            _ => {
                return Err(String::from(
                    "audioloader: found unsupported audio format (supported: wav, ogg)",
                ))
            }
        };

        let resample = Self::needs_resampling(&format, target_samplerate)?;

        if resample {
            values = AudioResampler::resample(&values, format.sample_rate, target_samplerate)?;
        }
        Ok(AudioData::new(values, resample))
    }
    // ------------------------------------------------------------------------
    fn needs_resampling(spec: &FormatSpec, target_samplerate: u32) -> Result<bool, String> {
        if *spec == FormatSpec::new(1, target_samplerate, 16) {
            Ok(false)
        } else if spec.channels == 1 && spec.sample_rate >= target_samplerate {
            Ok(true)
        } else {
            Err(format!(
                "expected format >= {} Hz, 16 bit, 1 channel. \
                 found {} Hz, {} bit, {} channel(s)",
                target_samplerate, spec.sample_rate, spec.bits, spec.channels
            ))
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl AudioResampler {
    // ------------------------------------------------------------------------
    pub fn resample(values: &[i16], from_hz: u32, to_hz: u32) -> Result<Vec<i16>, String> {
        use self::sample::interpolate::Linear;
        use self::sample::{signal, Sample, Signal};

        let old_sample_rate: f64 = from_hz.into();
        let new_sample_rate: f64 = to_hz.into();

        let mut signal = signal::from_iter(values.iter().map(|s| [(*s as i16).to_sample::<f64>()]));

        let new_len = (values.len() as f64 * new_sample_rate / old_sample_rate) as usize;
        let interp = Linear::from_source(&mut signal);
        let conv = signal.from_hz_to_hz(interp, old_sample_rate, new_sample_rate);

        Ok(conv
            .take(new_len)
            .map(|f| f[0].to_sample::<i16>())
            .collect())
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
// inspired by rodios decoder implementations
// ----------------------------------------------------------------------------
// Wav
// ----------------------------------------------------------------------------
use std::fs::File;
use std::io::BufReader;

struct WavDecoder {
    reader: hound::WavReader<BufReader<File>>,
}
// ----------------------------------------------------------------------------
impl WavDecoder {
    // ------------------------------------------------------------------------
    fn new(filename: &str) -> Result<WavDecoder, String> {
        let reader = hound::WavReader::open(filename).map_err(|e| format!("WavLoader: {}", e))?;

        Ok(WavDecoder { reader })
    }
    // ------------------------------------------------------------------------
    fn format(&self) -> FormatSpec {
        self.reader.spec().into()
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl Iterator for WavDecoder {
    type Item = i16;
    // ------------------------------------------------------------------------
    #[inline]
    fn next(&mut self) -> Option<i16> {
        if let Some(value) = self.reader.samples().next() {
            Some(value.unwrap_or(0))
        } else {
            None
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl From<hound::WavSpec> for FormatSpec {
    // ------------------------------------------------------------------------
    fn from(spec: hound::WavSpec) -> FormatSpec {
        FormatSpec {
            channels: spec.channels as u8,
            sample_rate: spec.sample_rate,
            bits: spec.bits_per_sample,
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
// Ogg Vorbis
// ----------------------------------------------------------------------------
use self::lewton::inside_ogg::OggStreamReader;
use std::vec;

struct OggDecoder {
    reader: OggStreamReader<File>,
    packet_data: vec::IntoIter<i16>,
}
// ----------------------------------------------------------------------------
impl OggDecoder {
    // ------------------------------------------------------------------------
    fn new(filename: &str) -> Result<OggDecoder, String> {
        let f = File::open(filename).map_err(|e| format!("OggLoader: {}", e))?;
        let mut reader = OggStreamReader::new(f).map_err(|e| format!("OggLoader: {}", e))?;


        // The first packet is always empty => prefetch directly
        let data = match reader.read_dec_packet_itl().ok().and_then(|v| v) {
            Some(d) => d,
            None => Vec::new(),
        };

        Ok(OggDecoder {
            reader,
            packet_data: data.into_iter(),
        })
    }
    // ------------------------------------------------------------------------
    fn format(&self) -> FormatSpec {
        FormatSpec {
            channels: self.reader.ident_hdr.audio_channels,
            sample_rate: self.reader.ident_hdr.audio_sample_rate,
            bits: 16,
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl Iterator for OggDecoder {
    type Item = i16;
    // ------------------------------------------------------------------------
    #[inline]
    fn next(&mut self) -> Option<i16> {
        if let Some(value) = self.packet_data.next() {
            Some(value)
        } else {
            // read next packet
            self.packet_data = match self.reader.read_dec_packet_itl() {
                Err(msg) => {
                    error!("OggLoader: {}", msg);
                    return None;
                }
                Ok(packet) => match packet {
                    Some(data) => data.into_iter(),
                    None => return None,
                },
            };
            self.packet_data.next()
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
