//
// interactive view::misc
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub(in gui) fn render<'a>(
    ui: &Ui<'a>,
    fonts: &Fonts,
    area: &UiArea,
    settings: &Settings,
    track: &PhonemeTrack<PhonemeSegment>,
) -> Option<EditorAction> {
    let mut result = None;

    let padding = ui.imgui().style().window_padding;
    ui.with_style_var(
        imgui::StyleVar::WindowPadding((padding.x, 0.0).into()),
        || {
            ui.window(im_str!("Additional Information"))
                .show_borders(false)
                .title_bar(false)
                .menu_bar(false)
                .movable(false)
                .resizable(false)
                .collapsible(false)
                .no_bring_to_front_on_focus(true)
                .position(area.pos, imgui::ImGuiCond::Always)
                .size(area.size, imgui::ImGuiCond::Always)
                .build(|| {
                    if ui
                        .collapsing_header(im_str!("input text"))
                        .default_open(true)
                        .build()
                    {
                        show_input_text(ui, track.input_text());
                    };

                    if ui.collapsing_header(im_str!("phoneme translation")).build() {
                        show_phoneme_translation(ui, fonts, track.translation());
                    };

                    if ui
                        .collapsing_header(im_str!("phoneme block drag mode"))
                        .build()
                    {
                        result = show_drag_settings(ui, settings);
                    }

                    if ui.collapsing_header(im_str!("loaded phoneme data")).build() {
                        show_phonemes_traceback(ui, fonts, track);
                    }
                });
        },
    );
    result
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use imgui;
use imgui::Ui;

use super::EditorAction;

use super::Settings;
use super::{Fonts, UiArea};
use super::{PhonemeDragMode, PhonemeSegment, PhonemeTrack};
// ----------------------------------------------------------------------------
// ui rendering helpers
// ----------------------------------------------------------------------------
#[inline]
fn show_input_text<'a>(ui: &'a Ui, input_text: &str) {
    ui.spacing();
    ui.spacing();
    ui.text_wrapped(&imgui::ImString::new(input_text));
    ui.spacing();
    ui.spacing();
}
// ----------------------------------------------------------------------------
#[inline]
fn show_phoneme_translation<'a>(ui: &'a Ui, fonts: &Fonts, translation: &str) {
    ui.with_font(fonts.phonemes(), || {
        ui.spacing();
        ui.spacing();
        ui.text_wrapped(&imgui::ImString::new(translation));
        ui.spacing();
        ui.spacing();
    });
}
// ----------------------------------------------------------------------------
#[inline]
fn show_drag_settings<'a>(ui: &'a Ui, settings: &Settings) -> Option<EditorAction> {
    let mut result = None;
    ui.spacing();
    if ui.radio_button_bool(
        im_str!("word bound"),
        *settings.drag_mode() == PhonemeDragMode::Words,
    ) {
        result = Some(EditorAction::SetDragMode(PhonemeDragMode::Words));
    }
    ui.same_line(0.0);
    if ui.radio_button_bool(
        im_str!("adjacent"),
        *settings.drag_mode() == PhonemeDragMode::Neighbour,
    ) {
        result = Some(EditorAction::SetDragMode(PhonemeDragMode::Neighbour));
    }
    ui.same_line(0.0);
    if ui.radio_button_bool(
        im_str!("unconstrained"),
        *settings.drag_mode() == PhonemeDragMode::None,
    ) {
        result = Some(EditorAction::SetDragMode(PhonemeDragMode::None));
    }
    ui.spacing();
    result
}
// ----------------------------------------------------------------------------
#[inline]
fn show_phonemes_traceback<'a>(ui: &'a Ui, fonts: &Fonts, track: &PhonemeTrack<PhonemeSegment>) {
    ui.child_frame(im_str!("##phoneme_traceback_table"), (0.0, -5.0))
        .build(|| {
            ui.with_font(fonts.phonemes(), || {
                ui.text(&imgui::ImString::new(
                    ";phoneme |start|  end|weight| score| status     | match + pocketsphinx timing",
                ));
                ui.separator();

                ui.child_frame(im_str!("##phoneme_traceback"), (0.0, -5.0))
                    .build(|| {
                        phoneme_traceback(ui, track);
                    });
            });
        });
}
// ----------------------------------------------------------------------------
#[inline]
fn phoneme_traceback<'a>(ui: &Ui<'a>, track: &PhonemeTrack<PhonemeSegment>) {
    let empty = String::from("");

    for (i, segment) in track.phonemes().iter().enumerate() {
        if i > 0 && segment.word_start {
            ui.separator();
        }

        let color_modifier = if segment.active { 0.9 } else { 0.7 };
        let color = if segment.score < 0.0 {
            (color_modifier, color_modifier, 0.1, color_modifier)
        } else {
            (
                color_modifier,
                color_modifier,
                color_modifier,
                color_modifier,
            )
        };

        // workaround for misalignment of columns for the ; deactivated-marker
        if segment.active {
            ui.text_colored(
                color,
                im_str!(" {}", segment.traceback.as_ref().unwrap_or(&empty)),
            );
        } else {
            ui.text_colored(
                color,
                im_str!("{}", segment.traceback.as_ref().unwrap_or(&empty)),
            );
        }
    }
}
// ----------------------------------------------------------------------------
