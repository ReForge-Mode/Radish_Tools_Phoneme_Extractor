//
// gui: audio player
//
extern crate cpal;
extern crate futures;

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub(super) struct Player {
    samplerate: u32,
    player: Arc<RwLock<AudioPlayer>>,
    data: Arc<AudioData>,
}
// ----------------------------------------------------------------------------
#[derive(Clone)]
pub enum PlaybackState {
    Idle,
    Playing,
}
// ----------------------------------------------------------------------------
pub(super) fn init() -> Result<Player, String> {
    let (playback_format, voice, stream, event_loop) = init_playback_device()?;

    // access with multiple threads => shared with arcs and atomic/rwlocks
    let playerdata = Player {
        samplerate: playback_format.samples_rate.0,
        player: Arc::new(RwLock::new(AudioPlayer::new(voice))),
        data: Arc::new(AudioData::new()),
    };

    // background tasks to refill playback buffer
    init_playback_thread(
        playerdata.player.clone(),
        playerdata.data.clone(),
        stream,
        playback_format.channels.len(),
    );

    // event_loop.run blocks indefinitely -> move to own thread
    thread::spawn(move || {
        event_loop.run();
    });

    Ok(playerdata)
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use self::futures::stream::Stream;
use self::futures::task;
#[allow(deprecated)]
use self::futures::task::Executor;
#[allow(deprecated)]
use self::futures::task::Run;

use std::thread;


use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, RwLock};
struct AudioPlayer {
    state: PlaybackState,
    voice: cpal::Voice,
}
// ----------------------------------------------------------------------------
struct AudioData {
    audio: RwLock<Vec<i16>>,
    startpos: AtomicUsize,
    endpos: AtomicUsize,
    playpos: AtomicUsize,
    datapos: AtomicUsize,
}
// ----------------------------------------------------------------------------
impl AudioPlayer {
    // ------------------------------------------------------------------------
    fn new(voice: cpal::Voice) -> AudioPlayer {
        AudioPlayer {
            state: PlaybackState::Idle,
            voice,
        }
    }
    // ------------------------------------------------------------------------
    fn stop(&mut self) {
        self.state = PlaybackState::Idle;
        self.voice.pause();
    }
    // ------------------------------------------------------------------------
    fn play(&mut self) {
        self.state = PlaybackState::Playing;
        self.voice.play();
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl AudioData {
    // ------------------------------------------------------------------------
    fn new() -> AudioData {
        AudioData {
            audio: RwLock::new(Vec::default()),
            startpos: AtomicUsize::new(0),
            endpos: AtomicUsize::new(0),
            playpos: AtomicUsize::new(0),
            datapos: AtomicUsize::new(0),
        }
    }
    // ------------------------------------------------------------------------
    #[inline]
    fn playpos(&self) -> usize {
        self.playpos.load(Ordering::SeqCst)
    }
    // ------------------------------------------------------------------------
    fn rewind(&self) {
        let startpos = self.startpos.load(Ordering::SeqCst);
        self.datapos.store(startpos, Ordering::SeqCst);
        // self.playpos.store(startpos, Ordering::SeqCst);
    }
    // ------------------------------------------------------------------------
    fn seek(&self, pos: usize) {
        self.startpos.store(pos, Ordering::SeqCst);
        self.rewind();
    }
    // ------------------------------------------------------------------------
    fn clip_at(&self, pos: usize) {
        if self.startpos.load(Ordering::SeqCst) < pos {
            self.endpos.store(pos, Ordering::SeqCst);
        }
    }
    // ------------------------------------------------------------------------
    #[inline]
    fn set(&self, data: Vec<i16>) -> Result<(), String> {
        let samples = data.len();
        {
            match self.audio.write() {
                Ok(mut buf) => *buf = data,
                Err(_) => return Err(String::from("could not aquire write lock on playerbuf")),
            }
        }
        self.startpos.store(0, Ordering::SeqCst);
        self.endpos.store(samples, Ordering::SeqCst);
        self.datapos.store(0, Ordering::SeqCst);
        self.playpos.store(0, Ordering::SeqCst);
        Ok(())
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl Player {
    // ------------------------------------------------------------------------
    #[inline]
    pub fn playback_samplerate(&self) -> u32 {
        self.samplerate
    }
    // ------------------------------------------------------------------------
    #[inline]
    pub fn playpos(&self) -> usize {
        //FIXME this doesn't work sufficiantly. position of requested data depends
        // on the prebuffering which is too big (at least at the start of playback)
        // try to calculate by using startpos + (now - playstart)*samplerate timestamps?
        self.data.playpos()
    }
    // ------------------------------------------------------------------------
    pub fn state(&self) -> Result<PlaybackState, String> {
        match self.player.read() {
            Ok(player) => Ok(player.state.clone()),
            Err(_) => Err(String::from(
                "player: could not acquire read lock on player",
            )),
        }
    }
    // ------------------------------------------------------------------------
    pub fn set_data(&mut self, data: Vec<i16>) -> Result<(), String> {
        self.data.set(data)
    }
    // ------------------------------------------------------------------------
    pub fn seek(&self, pos: usize) {
        self.data.seek(pos)
    }
    // ------------------------------------------------------------------------
    pub fn clip_at(&self, pos: usize) {
        self.data.clip_at(pos)
    }
    // ------------------------------------------------------------------------
    pub fn play(&self) -> Result<(), String> {
        match self.player.write() {
            Ok(mut player) => {
                self.data.rewind();
                player.play();
                Ok(())
            }
            Err(_) => Err(String::from(
                "player: could not acquire read lock on player",
            )),
        }
    }
    // ------------------------------------------------------------------------
    pub fn stop(&self) -> Result<(), String> {
        match self.player.write() {
            Ok(mut player) => {
                player.stop();
                self.data.playpos.store(0, Ordering::SeqCst);
                Ok(())
            }
            Err(_) => Err(String::from(
                "player: could not acquire read lock on player",
            )),
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
// cpal init
// ----------------------------------------------------------------------------
use self::cpal::{EventLoop, Format, SamplesStream, Voice};
// ----------------------------------------------------------------------------
struct MyExecutor;
// ----------------------------------------------------------------------------
#[allow(deprecated)]
impl Executor for MyExecutor {
    fn execute(&self, r: Run) {
        r.run();
    }
}
// ----------------------------------------------------------------------------
fn init_playback_device() -> Result<(Format, Voice, SamplesStream, EventLoop), String> {
    let endpoint = cpal::default_endpoint()
        .ok_or_else(|| String::from("player: failed to get default audio device"))?;

    // preferred playback format is 44.1khz 16bit mono
    // but fallback to anything >= 44.1kHz is usable, too
    let format = endpoint
        .supported_formats()
        .map_err(|err| format!("player: format selection error: {}", err))?
        .fold(None, select_best_format)
        .ok_or_else(|| {
            String::from(
            "player: no audio device found for playback (required playback sample rate >=44.1kHz)")
        })?;

    let event_loop = cpal::EventLoop::new();

    let (voice, stream) = cpal::Voice::new(&endpoint, &format, &event_loop)
        .map_err(|e| format!("player: failed to create a voice: {}", e))?;

    Ok((format, voice, stream, event_loop))
}
// ----------------------------------------------------------------------------
fn init_playback_thread(
    player: Arc<RwLock<AudioPlayer>>,
    data: Arc<AudioData>,
    stream: SamplesStream,
    playback_channels: usize,
) {
    let executor = Arc::new(MyExecutor);

    #[allow(deprecated)]
    task::spawn(stream.for_each(move |buffer| -> Result<_, ()> {
        let pos = data.datapos.load(Ordering::SeqCst);
        let endpos = data.endpos.load(Ordering::SeqCst);
        data.playpos.store(pos, Ordering::SeqCst);
        let mut len = 0;

        match data.audio.read() {
            Ok(audiodata) => {
                if pos < endpos {
                    match buffer {
                        cpal::UnknownTypeBuffer::I16(mut buffer) => {
                            for (sample, value) in buffer
                                .chunks_mut(playback_channels)
                                .zip((*audiodata).iter().take(endpos).skip(pos))
                            {
                                for out in sample.iter_mut() {
                                    *out = *value;
                                }
                                len += 1;
                            }
                        }
                        cpal::UnknownTypeBuffer::F32(mut buffer) => {
                            for (sample, value) in buffer
                                .chunks_mut(playback_channels)
                                .zip((*audiodata).iter().take(endpos).skip(pos))
                            {
                                let value = f32::from(*value) / f32::from(i16::max_value());
                                for out in sample.iter_mut() {
                                    *out = value;
                                }
                                len += 1;
                            }
                        }
                        cpal::UnknownTypeBuffer::U16(mut buffer) => {
                            for (sample, value) in buffer
                                .chunks_mut(playback_channels)
                                .zip((*audiodata).iter().take(endpos).skip(pos))
                            {
                                let value = (((f32::from(*value) / f32::from(i16::max_value()))
                                    + 0.5)
                                    * f32::from(u16::max_value()))
                                    as u16;
                                for out in sample.iter_mut() {
                                    *out = value;
                                }
                                len += 1;
                            }
                        }
                    }
                    // note: this will overshoot the actual datapos at the end but the if
                    // condition will prevent next refill anyway
                    data.datapos.store(pos + len, Ordering::SeqCst);
                } else {
                    match player.write() {
                        Ok(mut player) => player.stop(),
                        Err(_) => error!("player: failed to acquire audioplayer write lock"),
                    }
                    data.playpos.store(0, Ordering::SeqCst);
                }
            }
            Err(_) => error!("player: failed to acquire audiobuf read lock"),
        }
        Ok(())
    }))
    .execute(executor);
}
// ----------------------------------------------------------------------------
fn select_best_format(best_found: Option<Format>, format: Format) -> Option<Format> {
    let cpal::SamplesRate(sample_rate) = format.samples_rate;

    trace!(
        "> available playback format: {} Hz {} channels {:?} bit",
        sample_rate,
        format.channels.len(),
        format.data_type
    );

    if sample_rate >= 44100 {
        if let Some(ref current) = best_found {
            // try to match 44100 16bit mono
            if format.samples_rate < current.samples_rate
                || format.channels.len() < current.channels.len()
            {
                trace!(">> selecting [better samplingrate/channel count]");
                return Some(format);
            } else if format.data_type == cpal::SampleFormat::I16
                && format.samples_rate == current.samples_rate
                && format.channels.len() == current.channels.len()
            {
                trace!(">> selecting [better datatype]");
                return Some(format);
            }
        } else {
            trace!(">> selecting.");
            return Some(format);
        }
    }
    best_found
}
// ----------------------------------------------------------------------------
