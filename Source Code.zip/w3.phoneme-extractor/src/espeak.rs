//
// phoneme translator
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
extern crate espeak;

pub use self::espeak::ESpeak;
// ----------------------------------------------------------------------------
pub trait TextPhonemeTranslator {
    // ------------------------------------------------------------------------
    fn translate(&self, text: &str) -> Result<PhonemeResult, String>;
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use phonemes::{PhonemeResult, PhonemeSegment};

const DEFAULT_DURATION: u32 = 75;
const STRETCHED_DURATION: u32 = 150;
// ----------------------------------------------------------------------------
impl PhonemeSegment {
    // ------------------------------------------------------------------------
    fn new_from_generated(phoneme: &str, start: u32, word_position: usize) -> PhonemeSegment {

        // : indicates longer phoneme
        let (filtered, end) = if phoneme.contains("ː") {
            (phoneme.replace("ː", ""), start + STRETCHED_DURATION)
        } else {
            (phoneme.to_owned(), start + DEFAULT_DURATION)
        };

        let (filtered, weight) = if filtered.contains("ˈ") {
            // primary stress -> add some more weight
            (filtered.replace("ˈ", ""), 1.1)
        } else if filtered.contains("ˌ") {
            // secondary stress -> add less weight
            (filtered.replace("ˌ", ""), 1.05)
        } else {
            // defaults
            (filtered, 1.0)
        };

        PhonemeSegment {
            phoneme: filtered,
            word_start: word_position == 0,
            start,
            end,
            weight,
            score: 1.0,
            matching_info: None,
            traceback: None,
            active: true,
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl TextPhonemeTranslator for ESpeak {
    // ------------------------------------------------------------------------
    fn translate(&self, text: &str) -> Result<PhonemeResult, String> {
        debug!("text to translate  : {}", text);

        let mut phonemes = Vec::new();

        // result will have blanks as word separator and _ as phoneme separator
        let result = match self.convert_to_phonemes(text, true) {
            Ok(string) => string,
            Err(why) => return Err(why),
        };
        let result = result.trim();

        // remove phoneme separator for debug output string
        let hypothesis = if !result.is_empty() {
            Some(result.replace("_", ""))
        } else {
            None
        };

        let words: Vec<&str> = result.split(' ').collect();

        // duration is saved ms (intervals more or less like pocketsphinx' frames)
        // use equidistant phoneme intervals starting with a silent one
        let mut time = DEFAULT_DURATION;
        for word in words {

            for (i, phoneme) in word.split('_').enumerate() {
                // skip "empty" phonemes
                if !phoneme.is_empty() {
                    let p = PhonemeSegment::new_from_generated(phoneme, time, i);
                    time = p.end;

                    phonemes.push(p);
                }
            }

            // add silence at end of every word
            time += DEFAULT_DURATION;
        }

        Ok(PhonemeResult {
            hypothesis,
            phonemes,
        })
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------

