//
// gui: settings for editor
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
#[derive(PartialEq, Debug)]
pub(super) enum PhonemeDragMode {
    None,
    Neighbour,
    Words,
}
// ----------------------------------------------------------------------------
pub(super) struct Settings {
    drag_mode: PhonemeDragMode,
    drag_damping: f32,
    granularity_ms: f32,
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
impl Default for Settings {
    fn default() -> Settings {
        Settings {
            drag_mode: PhonemeDragMode::default(),
            drag_damping: 0.5,
            granularity_ms: 5.0,
        }
    }
}
// ----------------------------------------------------------------------------
impl Default for PhonemeDragMode {
    fn default() -> PhonemeDragMode {
        PhonemeDragMode::Words
    }
}
// ----------------------------------------------------------------------------
impl Settings {
    // ------------------------------------------------------------------------
    #[inline]
    pub fn drag_mode(&self) -> &PhonemeDragMode {
        &self.drag_mode
    }
    // ------------------------------------------------------------------------
    #[inline]
    pub fn drag_damping(&self) -> f32 {
        self.drag_damping
    }
    // ------------------------------------------------------------------------
    #[inline]
    pub fn granularity_ms(&self) -> f32 {
        self.granularity_ms
    }
    // ------------------------------------------------------------------------
    #[inline]
    pub fn set_drag_mode(&mut self, new_mode: PhonemeDragMode) {
        self.drag_mode = new_mode;
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
