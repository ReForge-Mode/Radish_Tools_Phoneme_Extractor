//
// phonemes datastructures and file encoding/decoding
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
#[derive(Clone, Default)]
pub struct PhonemeSegment {
    pub phoneme: String,
    pub word_start: bool,
    pub start: u32,
    pub end: u32,
    pub weight: f32,
    pub score: f32,
    pub matching_info: Option<String>,
    pub traceback: Option<String>,
    pub active: bool,
}
// ----------------------------------------------------------------------------
pub struct PhonemeResult {
    pub hypothesis: Option<String>,
    pub phonemes: Vec<PhonemeSegment>,
}
// ----------------------------------------------------------------------------
#[derive(Default, Clone, Eq, PartialEq)]
pub struct PhonemeTrack<T> {
    id: u32,
    version: u16,
    language: String,
    input_text: String,
    translation: String,
    audio_hypothesis: Option<String>,
    phonemes: Vec<T>,
}
// ----------------------------------------------------------------------------
pub fn store(outputpath: &PathBuf, data: PhonemeTrack<PhonemeSegment>) -> Result<String, String> {
    let mut path = PathBuf::from(outputpath);
    path.push(format!("{:010}.phonemes", data.id));

    save_as_csv(&path, &data)?;

    Ok(path.to_string_lossy().into())
}
// ----------------------------------------------------------------------------
pub fn load(id: u32, path: &PathBuf) -> Result<PhonemeTrack<PhonemeSegment>, String> {
    // overwrite id as it is not stored in the meta information
    PhonemeTrack::load(path).map(|mut track| {
        track.id = id;
        track
    })
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use std::io::BufRead;
use std::path::PathBuf;
use text::{CsvLoader, CsvWriter, SimpleCsvWriter};

use sequence_matcher::WARN_MATCHING_SCORE_MIN;
// ----------------------------------------------------------------------------
impl<T> PhonemeTrack<T> {
    // ------------------------------------------------------------------------
    pub fn new(
        id: u32,
        language: &str,
        text: &str,
        translation: &str,
        audio_hypothesis: Option<String>,
        phonemes: Vec<T>,
    ) -> PhonemeTrack<T> {
        PhonemeTrack {
            id,
            version: 1,
            language: language.to_owned(),
            input_text: text.to_owned(),
            translation: translation.to_owned(),
            audio_hypothesis,
            phonemes,
        }
    }
    // ------------------------------------------------------------------------
    pub fn id(&self) -> u32 {
        self.id
    }
    // ------------------------------------------------------------------------
    pub fn version(&self) -> u16 {
        self.version
    }
    // ------------------------------------------------------------------------
    pub fn language(&self) -> &str {
        &self.language
    }
    // ------------------------------------------------------------------------
    pub fn input_text(&self) -> &str {
        &self.input_text
    }
    // ------------------------------------------------------------------------
    pub fn translation(&self) -> &str {
        &self.translation
    }
    // ------------------------------------------------------------------------
    pub fn audio_hypothesis(&self) -> &Option<String> {
        &self.audio_hypothesis
    }
    // ------------------------------------------------------------------------
    pub fn phonemes(&self) -> &Vec<T> {
        &self.phonemes
    }
    // ------------------------------------------------------------------------
    pub fn phonemes_mut(&mut self) -> &mut Vec<T> {
        &mut self.phonemes
    }
    // ------------------------------------------------------------------------
    pub fn set_version(&mut self, version: u16) {
        self.version = version
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl<T> PhonemeTrack<T> {
    // ------------------------------------------------------------------------
    fn is_headerline(line: &str) -> bool {
        let cols = line
            .split('|')
            .map(|c| c.trim().to_lowercase())
            .collect::<Vec<_>>();

        cols.len() > 3
            && cols[0] == ";phoneme"
            && cols[1] == "start"
            && cols[2] == "end"
            && cols[3] == "weight"
        //&& cols[4] == "score"
    }
    // ------------------------------------------------------------------------
    fn parse_segment(input_line: &str, new_word: bool) -> Result<PhonemeSegment, String> {
        let (active, line) = if input_line.starts_with(';') {
            (false, &input_line[1..])
        } else {
            (true, input_line)
        };
        let data: Vec<_> = line.split('|').map(str::trim).collect();

        if data.len() > 3 {
            let mut segment = PhonemeSegment {
                phoneme: data[0].to_string(),
                word_start: new_word,
                start: data[1]
                    .parse::<u32>()
                    .map_err(|e| format!("col #1: {}", e))?,
                end: data[2]
                    .parse::<u32>()
                    .map_err(|e| format!("col #2: {}", e))?,
                weight: data[3]
                    .parse::<f32>()
                    .map_err(|e| format!("col #3: {}", e))?,
                score: 0.0,

                matching_info: None,
                traceback: Some(input_line.to_owned()),
                active,
            };

            if data.len() > 4 {
                segment.score = data[4]
                    .parse::<f32>()
                    .map_err(|e| format!("col #4: {}", e))?;
            }
            // ignore col 5 with status
            if data.len() > 6 {
                segment.matching_info = Some(data[6].to_owned());
            }
            Ok(segment)
        } else {
            Err(format!(
                "data line must contain at least 4 columns (phoneme, start, end, \
                 weight, [score]). found: {}",
                data.len()
            ))
        }
    }
    // ------------------------------------------------------------------------
    fn legacy_parse(line: &str) -> Result<String, String> {
        match line.find(':') {
            Some(pos) => Ok(line[pos + 1..].trim_matches('"').to_owned()),
            None => Err(String::from(
                "could not parse legacy format (missing separator).",
            )),
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
use std::str::FromStr;
// ----------------------------------------------------------------------------
impl CsvLoader<PhonemeTrack<PhonemeSegment>> for PhonemeTrack<PhonemeSegment> {
    // ------------------------------------------------------------------------
    fn load(filepath: &PathBuf) -> Result<PhonemeTrack<PhonemeSegment>, String> {
        let reader = Self::create_reader(filepath)?;

        let mut track = PhonemeTrack::default();
        let mut header_found = false;
        let mut new_word_starting = false;

        for (pos, line) in reader.lines().enumerate() {
            let err_format = |e: &str| -> String {
                format!("phonemes loader: error reading line {}: {}", pos + 1, e)
            };

            let line = line.map_err(|e| err_format(&e.to_string()))?;

            if !header_found {
                match line.as_str() {
                    l if l.starts_with(";meta") => {
                        match Self::parse_meta(l).map_err(|e| err_format(&e))? {
                            (key, value) if key == "language" => track.language = value.to_owned(),
                            (key, value) if key == "text" => track.input_text = value.to_owned(),
                            (key, value) if key == "translation" => {
                                track.translation = value.to_owned()
                            }
                            (key, value) if key == "audio-hypothesis" => {
                                track.audio_hypothesis = Some(value.to_owned())
                            }
                            (key, value) if key == "version" => {
                                track.version =
                                    u16::from_str(value).map_err(|e| err_format(&e.to_string()))?
                            }
                            (key, _) => {
                                return Err(err_format(&format!("found unsupported meta key [{}]", key)))
                            }
                        }
                    }

                    l if Self::is_headerline(l) => header_found = true,

                    // --- legacy format data extraction (without meta)
                    l if l.starts_with(";provided source text") => {
                        track.input_text = Self::legacy_parse(l)?
                    }
                    l if l.starts_with(";phoneme translation") => {
                        track.translation = Self::legacy_parse(l)?
                    }
                    l if l.starts_with(";audio hypothesis") => {
                        track.audio_hypothesis = Some(Self::legacy_parse(l)?)
                    }
                    // --- legacy format data end

                    l if l.starts_with(';') => continue,
                    _ => return Err(err_format(
                        "expected header line with column definition \
                         (phoneme, start, end, weight, [score]) before start of data block.",
                    )),
                }
            } else {
                match line.as_str() {
                    l if l.starts_with("---") => {
                        new_word_starting = true;
                        continue;
                    }
                    l => track
                        .phonemes
                        .push(Self::parse_segment(l, new_word_starting)?),
                }
                new_word_starting = false;
            }
        }
        debug!("read {} phoneme segments", track.phonemes.len());

        Ok(track)
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
fn save_as_csv(filepath: &PathBuf, data: &PhonemeTrack<PhonemeSegment>) -> Result<(), String> {
    let line_length;
    let mut writer = SimpleCsvWriter::create(&filepath)?;

    trace!("> writing csv header...");
    writer.write_meta("language", &data.language);
    writer.write_meta("version", &format!("{}", data.version));
    writer.write_meta("text", &data.input_text);
    writer.write_meta("translation", &data.translation);

    // available audio hypothesis means audio + translation data available
    if let Some(ref audio_hypothesis) = data.audio_hypothesis {
        writer.write_meta("audio-hypothesis", audio_hypothesis);
        writer.write_comment("");
        writer.write_comment(
            "auto-matched phoneme translation (eSpeak) with timings (pocketsphinx):",
        );
        writer.write_comment("");
        writer.write_header(
            "phoneme|start|  end|weight| score| status     | match + pocketsphinx timing",
        );
        line_length = 72;
    } else {
        writer.write_comment("");
        writer.write_header("phoneme|start|  end|weight| score| status");
        line_length = 48;
    }

    let empty_str = &String::from("");
    let word_seperator = &format!("{:-<1$}", "-", line_length);

    // write timings
    debug!("storing #{} phoneme timings", data.phonemes.len());
    for segment in &data.phonemes {
        let status = if segment.score < WARN_MATCHING_SCORE_MIN {
            "<- VERIFY!"
        } else {
            "ok"
        };
        let active = if segment.active { "" } else { ";" };
        if segment.word_start {
            writer.writeln(&word_seperator);
        }
        let line = format!(
            "{}{:<8}|{:>5}|{:>5}|{:>6.2}|{:>6.2}| {:<11}| {}",
            active,
            segment.phoneme,
            segment.start,
            segment.end,
            segment.weight,
            segment.score,
            status,
            segment
                .matching_info
                .as_ref()
                .map(|s| s.trim())
                .unwrap_or(empty_str)
        );

        writer.writeln(&line);
    }
    Ok(())
}
// ----------------------------------------------------------------------------
