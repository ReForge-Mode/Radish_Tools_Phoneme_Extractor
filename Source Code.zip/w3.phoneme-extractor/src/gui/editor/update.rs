//
// editor::update
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
#[inline]
pub(super) fn handle_action(
    action: EditorAction,
    state: &mut EditableData,
    settings: &mut Settings,
    player: &mut player::Player,
) -> Option<Action> {
    use self::EditorAction::*;

    let result = None;

    match action {
        Timeline(action) => {
            timeline::handle_action(action, settings, state, player);
        }

        SetDragMode(mode) => settings.set_drag_mode(mode),

        AutoCloseGaps => {
            auto_close_gaps(state.audio.duration_ms(), &mut state.phonemetrack);
        }

        ActivatePhonemeSegment(slot, activated) => {
            phonemes::update_timings_on_activation(
                state.audio.duration_ms(),
                &mut state.phonemetrack.phonemes_mut(),
                slot,
                activated,
            );
        }

        SetPhonemeSegmentPos(slot, start, end) => {
            let granularity = settings.granularity_ms();
            let duration = state.audio.duration_ms();

            state
                .phonemetrack
                .phonemes_mut()
                .iter_mut()
                .skip(slot)
                .take(1)
                .for_each(|segment| {
                    segment.start = clamp_ms(start, granularity, 0, segment.end);
                    segment.end = clamp_ms(end, granularity, segment.start, duration);
                });
        }

        SetPhonemeSegmentWeight(slot, weight) => {
            state
                .phonemetrack
                .phonemes_mut()
                .iter_mut()
                .skip(slot)
                .take(1)
                .for_each(|segment| segment.weight = weight);
        }
    }
    result
}
// ----------------------------------------------------------------------------
use super::phonemes;
use super::player;
use super::timeline;

// state
use super::{EditableData, Settings};

// actions
use gui::Action;
use super::Action as EditorAction;

// misc
use super::clamp_ms;
use super::{PhonemeSegment, PhonemeTrack};
// ----------------------------------------------------------------------------
fn auto_close_gaps(duration: u32, track: &mut PhonemeTrack<PhonemeSegment>) {
    let mut flipped = Vec::new();
    let mut segments = track.phonemes_mut();

    for (i, segment) in segments.iter_mut().enumerate() {
        if !segment.active && segment.phoneme.as_str() == "_" {
            segment.active = true;
            flipped.push(i);
        }
    }
    // workaround for borrow checker
    for slot in flipped {
        segments
            .iter_mut()
            .skip(slot)
            .take(1)
            .for_each(|segment| segment.active = false);
        phonemes::update_timings_on_activation(duration, &mut segments, slot, false);
    }
}
// ----------------------------------------------------------------------------
