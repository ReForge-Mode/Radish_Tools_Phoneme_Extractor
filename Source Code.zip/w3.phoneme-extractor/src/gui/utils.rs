//
// gui::utils
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub(super) struct ScreenSpaceManager {
    selection_queue: UiArea,
    timeline: UiArea,
    phoneme_table: UiArea,
    data_info: UiArea,
}
// ----------------------------------------------------------------------------
pub(super) struct UiArea {
    pub pos: (f32, f32),
    pub size: (f32, f32),
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
impl ScreenSpaceManager {
    // ------------------------------------------------------------------------
    pub fn new(winsize: (f32, f32)) -> ScreenSpaceManager {
        let (width, height) = winsize;
        let timeline_area = ((0.0, 19.0), (width, 220.0)).into();
        let selection_area = ((0.0, height - 212.0), (width, 212.0)).into();
        let middle_area_size = (width, height - (220.0 + 19.0 + 212.0));
        let phoneme_area = ((0.0, 239.0), (width * 0.5, middle_area_size.1)).into();
        let info_area = ((width * 0.5, 239.0), (width * 0.5, middle_area_size.1)).into();

        ScreenSpaceManager {
            selection_queue: selection_area,
            timeline: timeline_area,
            phoneme_table: phoneme_area,
            data_info: info_area,
        }
    }
    // ------------------------------------------------------------------------
    pub fn selection_queue(&self) -> &UiArea {
        &self.selection_queue
    }
    // ------------------------------------------------------------------------
    pub fn timeline(&self) -> &UiArea {
        &self.timeline
    }
    // ------------------------------------------------------------------------
    pub fn phoneme_table(&self) -> &UiArea {
        &self.phoneme_table
    }
    // ------------------------------------------------------------------------
    pub fn data_info(&self) -> &UiArea {
        &self.data_info
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl From<((f32, f32), (f32, f32))> for UiArea {
    fn from(v: ((f32, f32), (f32, f32))) -> UiArea {
        UiArea {
            pos: v.0,
            size: v.1,
        }
    }
}
// ----------------------------------------------------------------------------
