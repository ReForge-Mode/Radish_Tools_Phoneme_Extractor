# pocketsphinx Win 64 shared libs

Shared libraries for pocketsphinx sphinxbase.dll and pocketsphinx.dll compiled
from source (1+2) without modifications with MS Visual Studio Community 2015 (3)
as release build without debug infos for x64.

(1) https://github.com/cmusphinx/sphinxbase (rev bec67e5c2ed1ce2d375762d7b6bd86190a88826c)
(2) https://github.com/cmusphinx/pocketsphinx (rev dcc424c984cb5eb4fb0035e0162ad6dd67145863)
(3) https://www.visualstudio.com/
