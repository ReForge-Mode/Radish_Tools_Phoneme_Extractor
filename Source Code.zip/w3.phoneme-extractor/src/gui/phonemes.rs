//
// gui: extended phonemes datastructures for interactive adjustments
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
#[derive(Default, Clone)]
pub(super) struct PhonemeSegment {
    pub phoneme: String,
    pub word_start: bool,
    pub start: u32,
    pub end: u32,
    pub weight: f32,
    pub score: f32,
    pub matching_info: Option<String>,
    pub traceback: Option<String>,
    pub active: bool,
}
pub(super) use phonemes::PhonemeTrack;
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use phonemes::PhonemeSegment as RawPhonemeSegment;
// ----------------------------------------------------------------------------
impl<'a> From<&'a PhonemeTrack<RawPhonemeSegment>> for PhonemeTrack<PhonemeSegment> {
    // ------------------------------------------------------------------------
    fn from(track: &PhonemeTrack<RawPhonemeSegment>) -> PhonemeTrack<PhonemeSegment> {
        let phonemes = track.phonemes().iter().map(|p| p.into()).collect();
        let mut t = PhonemeTrack::new(
            track.id(),
            track.language(),
            track.input_text(),
            track.translation(),
            track.audio_hypothesis().clone(),
            phonemes,
        );
        t.set_version(track.version());
        t
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl<'a> From<&'a PhonemeTrack<PhonemeSegment>> for PhonemeTrack<RawPhonemeSegment> {
    // ------------------------------------------------------------------------
    fn from(track: &PhonemeTrack<PhonemeSegment>) -> PhonemeTrack<RawPhonemeSegment> {
        let phonemes = track.phonemes().iter().map(|p| p.into()).collect();
        let mut t = PhonemeTrack::new(
            track.id(),
            track.language(),
            track.input_text(),
            track.translation(),
            track.audio_hypothesis().clone(),
            phonemes,
        );
        t.set_version(track.version());
        t
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl<'a> From<&'a RawPhonemeSegment> for PhonemeSegment {
    // ------------------------------------------------------------------------
    fn from(raw: &RawPhonemeSegment) -> PhonemeSegment {
        PhonemeSegment {
            phoneme: raw.phoneme.clone(),
            word_start: raw.word_start,
            start: raw.start,
            end: raw.end,
            weight: raw.weight,
            score: raw.score,
            matching_info: raw.matching_info.clone(),
            traceback: raw.traceback.clone(),
            active: raw.active,
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl<'a> From<&'a PhonemeSegment> for RawPhonemeSegment {
    // ------------------------------------------------------------------------
    fn from(seg: &PhonemeSegment) -> RawPhonemeSegment {
        RawPhonemeSegment {
            phoneme: seg.phoneme.clone(),
            word_start: seg.word_start,
            start: seg.start,
            end: seg.end,
            weight: seg.weight,
            score: seg.score,
            matching_info: seg.matching_info.clone(),
            traceback: seg.traceback.clone(),
            active: seg.active,
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl PartialEq for PhonemeSegment {
    // ------------------------------------------------------------------------
    fn eq(&self, other: &PhonemeSegment) -> bool {
        // only the modifyable properties are required (and id)
        // self.word_start == other.word_start &&
        self.phoneme == other.phoneme &&
        self.start == other.start &&
        self.end == other.end &&
        self.weight == other.weight &&
        // self.score == other.score &&
        // self.matching_info == other.matching_info &&
        // self.traceback == other.traceback &&
        self.active == other.active
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
