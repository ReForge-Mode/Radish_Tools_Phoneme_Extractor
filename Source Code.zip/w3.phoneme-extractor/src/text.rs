//
// text provider
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub trait StringsProvider {
    // ------------------------------------------------------------------------
    fn get_lang(&self) -> &String;
    // ------------------------------------------------------------------------
    fn get_line(&self, id: u32) -> Result<&String, String>;
    // ------------------------------------------------------------------------
    fn get_all_lines(&self) -> &BTreeMap<u32, String>;
    // ------------------------------------------------------------------------
    fn get_all_lines_lowercased(&self) -> &Vec<(u32, String)>;
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
pub trait CsvLoader<T> {
    // ------------------------------------------------------------------------
    fn load(file: &PathBuf) -> Result<T, String>;
    // ------------------------------------------------------------------------
    fn create_reader(filepath: &PathBuf) -> Result<BufReader<File>, String> {
        debug!("opening {}...", filepath.display());

        let filepath = filepath
            .to_str()
            .ok_or_else(|| String::from("path to string conversion failed"))?;

        File::open(filepath)
            .map(BufReader::new)
            .map_err(|e| format!("couldn't open {}: {}", filepath, e))
    }
    // ------------------------------------------------------------------------
    fn parse_meta(line: &str) -> Result<(&str, &str), String> {
        if line.starts_with(";meta[") && line.ends_with(']') {
            let s = &line[6..line.len() - 1];
            match s.find('=') {
                Some(pos) => Ok((&s[0..pos], &s[pos + 1..])),
                None => Err(String::from("invalid meta format")),
            }
        } else {
            Err(String::from("line does not contain any meta data."))
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
pub trait CsvWriter {
    // ------------------------------------------------------------------------
    fn writeln(&mut self, line: &str);
    // ------------------------------------------------------------------------
    fn write_meta(&mut self, key: &str, value: &str) {
        self.writeln(&format!(";meta[{}={}]", key, value));
    }
    // ------------------------------------------------------------------------
    fn write_header(&mut self, line: &str) {
        self.writeln(&format!(";{}", line));
    }
    // ------------------------------------------------------------------------
    fn write_comment(&mut self, line: &str) {
        self.writeln(&format!(";{}", line));
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
pub struct CsvStringsData {
    lang: String,
    lines: BTreeMap<u32, String>,
    lines_lowercased: Vec<(u32, String)>,
}
// ----------------------------------------------------------------------------
pub struct SimpleCsvWriter {
    file: BufWriter<File>,
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use std::collections::BTreeMap;
use std::path::PathBuf;

use std::fs::File;
use std::io::{BufRead, BufReader, BufWriter, Write};

// ----------------------------------------------------------------------------
impl StringsProvider for CsvStringsData {
    // ------------------------------------------------------------------------
    fn get_lang(&self) -> &String {
        &self.lang
    }
    // ------------------------------------------------------------------------
    fn get_line(&self, id: u32) -> Result<&String, String> {
        match self.lines.get(&id) {
            Some(ref line) => Ok(line),
            None => Err(format!("string for id {} not found!", id)),
        }
    }
    // ------------------------------------------------------------------------
    fn get_all_lines(&self) -> &BTreeMap<u32, String> {
        &self.lines
    }
    // ------------------------------------------------------------------------
    fn get_all_lines_lowercased(&self) -> &Vec<(u32, String)> {
        &self.lines_lowercased
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl CsvStringsData {
    // ------------------------------------------------------------------------
    pub fn preprocess_lowercased(&mut self) {
        self.lines_lowercased = Vec::with_capacity(self.lines.len());

        for (id, line) in &self.lines {
            self.lines_lowercased.push((*id, line.to_lowercase()));
        }
    }
    // ------------------------------------------------------------------------
    fn extract_textline(textline: &str) -> Result<(u32, String), String> {
        let cols: Vec<&str> = textline.split('|').collect();

        if cols.len() < 4 {
            return Err(format!(
                "at least 4 columns required. found: {}",
                cols.len()
            ));
        }

        // first col is <=10 digit u32
        let id: u32 = match cols[0].trim().parse() {
            Ok(id) => id,
            Err(why) => return Err(format!("could not parse id [{}]: {}", cols[0], why)),
        };
        // 4th column is text
        let text = cols[3].trim().to_owned();

        Ok((id, text))
    }
    // ------------------------------------------------------------------------
    fn extract_language(textline: &str) -> Option<String> {
        let prefix = ";meta[language=";

        if textline.starts_with(prefix) && textline.ends_with(']') {
            let value = &textline[prefix.len()..textline.len() - 1];
            Some(String::from(value))
        } else {
            None
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl CsvLoader<CsvStringsData> for CsvStringsData {
    // ------------------------------------------------------------------------
    fn load(filepath: &PathBuf) -> Result<CsvStringsData, String> {

        let reader = Self::create_reader(filepath)?;

        let mut data = CsvStringsData {
            lang: "".to_owned(),
            lines: BTreeMap::new(),
            lines_lowercased: Vec::new(),
        };

        for (line, text) in reader.lines().enumerate() {

            let (id, text) = match text {

                Ok(ref text) if line == 0 => match Self::extract_language(text) {
                    Some(lang) => {
                        data.lang = lang;
                        continue;
                    }
                    None => {
                        return Err(format!(
                            "expected language definition in line 1. found: {}",
                            text
                        ))
                    }
                },

                Ok(ref text) if text.starts_with(';') => continue,

                Ok(ref text) => match Self::extract_textline(text) {
                    Ok(extracted_data) => extracted_data,
                    Err(why) => return Err(format!("error reading line {}: {}", line + 1, &why)),
                },

                Err(why) => {
                    return Err(format!("error reading line {}: {}", line + 1, &why))
                }
            };

            data.lines.insert(id, text);
        }

        info!("loaded {} strings", data.lines.len());

        Ok(data)
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl SimpleCsvWriter {
    // ------------------------------------------------------------------------
    pub fn create(path: &PathBuf) -> Result<SimpleCsvWriter, String> {
        trace!("creating {}...", path.display());

        let file = match File::create(path) {
            Ok(file) => file,
            Err(why) => return Err(format!("{}", &why)),
        };

        Ok(SimpleCsvWriter {
            file: BufWriter::new(file),
        })
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl CsvWriter for SimpleCsvWriter {
    // ------------------------------------------------------------------------
    fn writeln(&mut self, line: &str) {
        self.file.write_all(line.as_bytes()).unwrap();
        self.file.write_all(b"\n").unwrap();
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
