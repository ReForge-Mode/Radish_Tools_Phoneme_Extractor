//
// gui::view::menu
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
pub(in gui) fn render<'a>(ui: &Ui<'a>, state: &State) -> Option<MenuSelection> {
    let mut result = None;
    ui.main_menu_bar(|| {
        ui.menu(im_str!("File")).build(|| {
            if ui.menu_item(im_str!("Load audio")).build() {
                result = Some(MenuSelection::LoadFile);
            }
            if ui
                .menu_item(im_str!("Save current"))
                // .enabled(state.data.changed())
                .enabled(state.editor_data.is_available())
                .build()
            {
                result = Some(MenuSelection::SaveFile);
            }
            ui.separator();
            if ui
                .menu_item(im_str!("Rename all files"))
                .enabled(!state.audioqueue.is_empty())
                .build() {
                result = Some(MenuSelection::RenameAllFiles);
            }
            ui.separator();
            if ui.menu_item(im_str!("Quit")).build() {
                result = Some(MenuSelection::Quit);
            }
        });

        ui.menu(im_str!("Help")).build(|| {
            if ui.menu_item(im_str!("Documentation")).build() {
                result = Some(MenuSelection::ShowHelp);
            }
            ui.separator();
            if ui.menu_item(im_str!("About")).build() {
                result = Some(MenuSelection::ShowAbout);
            }
        });
    });
    result
}
// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use imgui::Ui;

use super::MenuSelection;

use super::State;
// ----------------------------------------------------------------------------
