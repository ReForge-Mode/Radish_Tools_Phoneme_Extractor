//
// rust wrapper for espeak-sys low level bindings
//

// ----------------------------------------------------------------------------
// external interface
// ----------------------------------------------------------------------------
extern crate espeak_sys as bindings;
extern crate libc;

pub struct ESpeak {
    datadir: String
}

// ----------------------------------------------------------------------------
// internals
// ----------------------------------------------------------------------------
use std::ptr;
use std::ffi::{ CString, CStr };
use libc::{ c_int, c_char };

use bindings::{
    espeak_ERROR,

    espeak_AUDIO_OUTPUT,

    espeakINITIALIZE_PHONEME_EVENTS,
    espeakINITIALIZE_PHONEME_IPA,

    espeakCHARS_UTF8,
};
// ----------------------------------------------------------------------------
impl ESpeak {
    // ------------------------------------------------------------------------
    pub fn new(datadir: &str) -> ESpeak {
        ESpeak {
            datadir: datadir.to_owned()
        }
    }
    // ------------------------------------------------------------------------
    pub fn init(&self) -> Result<(), String> {
        let data_dir = CString::new(self.datadir.clone()).unwrap();

        let res = unsafe {
            bindings::espeak_Initialize(espeak_AUDIO_OUTPUT::AUDIO_OUTPUT_SYNCHRONOUS,
                0,  // Buffer length. 0 == 200ms
                // eSpeak-data dir
                data_dir.as_ptr(),
                // Options.
                espeakINITIALIZE_PHONEME_EVENTS + espeakINITIALIZE_PHONEME_IPA
            )
        };

        if res == espeak_ERROR::EE_INTERNAL_ERROR as i32 {
            Err("eSpeak: failed to initialize.".to_owned())
        } else {
            unsafe {
                // TODO make input parameter
                // value=0  No phoneme output (default)
                // value=1  Output the translated phoneme symbols for the text
                    // value=2  as (1), but also output a trace of how the translation
                    //          was done (matching rules and list entries)
                    // value=3  as (1), but produces IPA rather than ascii phoneme names
                bindings::espeak_SetPhonemeTrace(3, ptr::null_mut());
            }
            Ok(())
        }
    }
    // ------------------------------------------------------------------------
    pub fn set_language(&self, language: &str) -> Result<(), String> {
        let voice = CString::new(language).unwrap();

        let result = unsafe { bindings::espeak_SetVoiceByName(voice.as_ptr()) };

        match result {
            espeak_ERROR::EE_OK => Ok(()),
            _ => Err(format!("eSpeak: failed to set language [{}]", language)),
        }
    }
    // ------------------------------------------------------------------------
    pub fn convert_to_phonemes(&self, text: &str, use_separator: bool)
        -> Result<String, String>
    {
        let s = CString::new(text).unwrap();

        // phonememode bits0-3
        //      0= just phonemes.
        //      1= include ties (U+361) for phoneme names of more than one letter.
        //      2= include zero-width-joiner for phoneme names of more than one letter.
        //      3= separate phonemes with underscore characters.
        //      4= eSpeak's ascii phoneme names.
        //      5= International Phonetic Alphabet (as UTF-8 characters).
        #[allow(clippy::match_bool)]
        let phonememode = match use_separator {
            true => 0b0001_1000 as c_int,
            false => 0b0001_0000 as c_int,
        };
        unsafe {

            let mut text_ptr = s.as_ptr() as * const libc::c_void;
            let mut phonemes_result = String::new();

            let mut err = None;

            // text_ptr: The address of a pointer to the input text
            // which is terminated by a zero character. On return from
            // espeak_TextToPhonemes the pointer has been advanced past
            // the text which has been translated, or else set to NULL
            // to indicate that the end of the text has been reached.
            while !text_ptr.is_null() {

                // returns a pointer to a character string which contains
                // the phonemes for the text up to end of a sentence, or
                // comma, semicolon, colon, or similar punctuation.

                // ownership of phonemes result stays in lib!
                let phonemes: *const c_char = bindings::espeak_TextToPhonemes(
                    &mut text_ptr, // *mut *const c_void
                    espeakCHARS_UTF8 as c_int,
                    phonememode);

                match CStr::from_ptr(phonemes).to_str() {
                    Ok(string) => phonemes_result.push_str(string),
                    Err(why) => {
                        err = Some(format!("eSpeak: failed to convert text to phonemes: {}", why));
                        break;
                    }
                }
            }
            match err {
                Some(err) => Err(err),
                None => Ok(phonemes_result)
            }
        }
    }
    // ------------------------------------------------------------------------
}
// ----------------------------------------------------------------------------
impl Drop for ESpeak {
    fn drop(&mut self) {
        unsafe {
            bindings::espeak_Terminate();
        }
    }
}
// ----------------------------------------------------------------------------
